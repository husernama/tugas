//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package kendaraan.util;

public interface ShootAble {
    void shoot(String target);
}
